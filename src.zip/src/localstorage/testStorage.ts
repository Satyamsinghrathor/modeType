import { TypingTestResultSchema, type TypingTestResult } from "../models/testResultType";
import {z} from "zod";

const STORAGE_KEY = "typing-test-results";

export function getTestResults(): TypingTestResult[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);

    if (!stored) return [];

    const parsed: unknown = JSON.parse(stored);

    const result =
      z.array(TypingTestResultSchema).safeParse(parsed);

    if (!result.success) {
      console.warn("Invalid typing test data");
      return [];
    }

    return result.data;
  } catch {
    return [];
  }
}

export function saveTestResult(
  result: Omit<TypingTestResult, "id" | "date">
): TypingTestResult {
  const results = getTestResults();

  const newResult: TypingTestResult = {
    ...result,
    id: crypto.randomUUID(),
    date: new Date().toISOString(),
  };

  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify([newResult, ...results])
  );

  return newResult;
}

export function clearTestResults() {
  localStorage.removeItem(STORAGE_KEY);
}