import { z } from "zod";

export const TypingTestResultSchema = z.object({
  id: z.string(),
  wpm: z.number().nonnegative(),
  rawwpm: z.number().nonnegative(),

  accuracy: z.number().min(0).max(100),
  rawaccuracy: z.number().min(0).max(100),

  errors: z.number().int().nonnegative(),
  skipped: z.number().int().nonnegative(),

  elapsedTime: z.number().positive(),
  wordsTyped: z.number().int().nonnegative(),

  wrongWords: z.array(z.string()),
  wrongLetters: z.array(z.string()),

  date: z.iso.datetime(),

  wpms: z.array(z.number().nonnegative()),
  consistency: z.number().min(0).max(100),

  mode: z.string(),
  type: z.string(),
});

export type TypingTestResult =
  z.infer<typeof TypingTestResultSchema>;