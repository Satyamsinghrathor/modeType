import {
  BarChart3,
  RotateCcw,
  ChevronRight,
  TriangleAlert,
  List,
  Rewind,
  Download,
} from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { useNavigate} from "react-router-dom";

type TestResultProps = {
  wpm: number;
  rawwpm: number;
  accuracy: number;
  rawaccuracy: number;
  errors: number;
  skipped: number;
  elapsedTime: number;
  wordsTyped: number;
  wrongWords: string[];
  wrongLetters: string[];
  wpms: number[];
  consistency: number;
  mode: string;
  type: string;
  selector: number;
};

export default function TestResult({
  wpm,
  rawwpm,
  accuracy,
  rawaccuracy,
  errors,
  skipped,
  elapsedTime,
  wordsTyped,
  wrongWords,
  wrongLetters,
  wpms,
  consistency,
            mode,
          type,
          selector
}: TestResultProps) {

  const navigate = useNavigate()

    useEffect(() => {
      function handleKeyDown(e: KeyboardEvent) {

              if (e.key === "Tab") {
        e.preventDefault();
        navigate("/")
        return;
      }

      if(e.key == ""){
        e.preventDefault()
        return;
      }
      }
  
      window.addEventListener(
        "keydown",
        handleKeyDown
      );
  
      return () => {
        window.removeEventListener(
          "keydown",
          handleKeyDown
        );
      };
    }, []);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);

    return `${String(minutes).padStart(2, "0")}:${String(
      remainingSeconds
    ).padStart(2, "0")}`;
  };

  const formatElapsedTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.floor(seconds % 60);

    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
      2,
      "0"
    )}:${String(remainingSeconds).padStart(2, "0")}`;
  };

  const characters = wordsTyped * 5;

  const characterStats = `${characters}/${errors}/${skipped}/0`;

  return (
    <div className="min-h-screen bg-[#191a1f] px-4 py-8 font-mono text-[#646669] sm:px-6 lg:px-8">
      <main className="mx-auto max-w-[1400px]">


        {/* ================= MAIN CARD ================= */}

        <section className="rounded-2xl border border-[#303238] bg-[#202126] p-5 shadow-xl sm:p-7 lg:p-8">
          {/* ================= TOP SECTION ================= */}

          <div className="grid gap-8 lg:grid-cols-[200px_1fr]">
            {/* ================= LEFT STATS ================= */}

            <div className="flex flex-row gap-10 lg:block lg:pt-3">
              {/* WPM */}

              <div>
                <div className="text-base uppercase tracking-wide text-[#646669]">
                  wpm
                </div>

                <div className="mt-1 font-sans text-6xl font-semibold leading-none text-[#e2b714] sm:text-7xl">
                  {Math.round(wpm)}
                </div>
              </div>

              {/* ACCURACY */}

              <div className="lg:mt-8">
                <div className="text-base uppercase tracking-wide text-[#646669]">
                  accuracy
                </div>

                <div className="mt-1 font-sans text-6xl font-semibold leading-none text-[#e2b714] sm:text-7xl">
                  {Math.round(accuracy)}%
                </div>
              </div>

              {/* TEST INFO */}

              <div className="hidden lg:block">
                <div className="my-8 h-px bg-[#35373c]" />

                <div>
                  <div className="mb-3 text-sm uppercase tracking-wide text-[#646669]">
                    test type
                  </div>

                  <div className="space-y-1.5 text-sm text-[#e2b714]">
                    <div>{mode} {selector}</div>
                    <div>{type}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* ================= GRAPH ================= */}

            <div
              className="
                relative
                flex
                min-h-[300px]
                items-center
                justify-center
                overflow-hidden
                rounded-xl
                border
                border-[#35383f]
                bg-[#1c1e23]
              "
            >
              {/* Fake grid */}

              <div className="pointer-events-none absolute inset-0 opacity-40">
                <div className="absolute inset-x-0 top-1/4 border-t border-[#303238]" />
                <div className="absolute inset-x-0 top-1/2 border-t border-[#303238]" />
                <div className="absolute inset-x-0 top-3/4 border-t border-[#303238]" />

                <div className="absolute inset-y-0 left-1/4 border-l border-[#303238]" />
                <div className="absolute inset-y-0 left-1/2 border-l border-[#303238]" />
                <div className="absolute inset-y-0 left-3/4 border-l border-[#303238]" />
              </div>

              <div className="relative z-10 text-center">
                <BarChart3
                  size={52}
                  strokeWidth={1.5}
                  className="mx-auto mb-4 text-[#646669]"
                />

                <div className="font-sans text-lg text-[#96989d]">
                  Performance graph
                </div>

                <div className="mt-2 text-xs text-[#646669]">
                  WPM, accuracy and errors over time
                </div>

                <div className="mt-4 rounded-md border border-[#35383f] bg-[#202126] px-3 py-1 text-xs text-[#646669]">
                  {wpms.length} data points
                </div>
              </div>
            </div>
          </div>

          {/* ================= MOBILE TEST INFO ================= */}

          <div className="mt-6 rounded-xl border border-[#35383f] bg-[#1c1e23] p-5 lg:hidden">
            <div className="mb-3 text-sm uppercase tracking-wide">
              test type
            </div>

            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-[#e2b714]">
              <span>words 25</span>
              <span>english</span>
              <span>no quit</span>
            </div>
          </div>

          {/* ================= METRICS ================= */}

          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Metric
              label="raw"
              value={`${Math.round(rawwpm)} wpm`}
              subValue={`clean accuracy ${Math.round(rawaccuracy)}%`}
            />

            <Metric
              label="characters"
              value={characterStats}
              subValue="correct / errors / skipped / extra"
            />

            <Metric
              label="consistency"
              value={Math.ceil(consistency)}
              subValue="calculated from WPM data"
            />

            <Metric
              label="time"
              value={formatTime(elapsedTime)}
              subValue={`${formatElapsedTime(elapsedTime)} session`}
            />
          </div>

          {/* ================= ERROR SUMMARY ================= */}

          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <InfoCard
              icon={<TriangleAlert size={18} />}
              label="errors"
              value={errors}
            />

            <InfoCard
              icon={<List size={18} />}
              label="skipped"
              value={skipped}
            />
          </div>

          {/* ================= WRONG LETTERS ================= */}

          {wrongLetters.length > 0 && (
            <div className="mt-5 rounded-xl border border-[#35383f] bg-[#1c1e23] p-5">
              <div className="mb-3 flex items-center gap-2 text-sm text-[#96989d]">
                <TriangleAlert size={16} />
                <span>mistakes</span>
              </div>

              <div className="flex flex-wrap gap-2">
                {wrongLetters.map((letter, index) => (
                  <span
                    key={`${letter}-${index}`}
                    className="rounded-md border border-[#453b27] bg-[#29251b] px-2.5 py-1 text-sm text-[#e2b714]"
                  >
                    {letter}
                  </span>
                ))}
              </div>
            </div>
          )}
          {/* ================= WRONG WORDS ================= */}

          {wrongWords.length > 0 && (
            <div className="mt-5 rounded-xl border border-[#35383f] bg-[#1c1e23] p-5">
              <div className="mb-3 flex items-center gap-2 text-sm text-[#96989d]">
                <TriangleAlert size={16} />
                <span>mistakes</span>
              </div>

              <div className="flex flex-wrap gap-2">
                {wrongWords.map((word, index) => (
                  <span
                    key={`${word}-${index}`}
                    className="rounded-md border border-[#453b27] bg-[#29251b] px-2.5 py-1 text-sm text-[#e2b714]"
                  >
                    {word}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* ================= DIVIDER ================= */}

          <div className="my-8 h-px bg-[#35373c]" />

          {/* ================= ACTIONS ================= */}

          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-5">
            <ActionButton
              icon={<RotateCcw size={21} />}
              label="restart"
              active
            />

            <ActionButton
              icon={<ChevronRight size={22} />}
              label="next"
            />

            <ActionButton
              icon={<TriangleAlert size={19} />}
              label="mistakes"
            />

            <ActionButton
              icon={<List size={20} />}
              label="details"
            />

            <ActionButton
              icon={<Rewind size={20} />}
              label="review"
            />

            <ActionButton
              icon={<Download size={19} />}
              label="export"
            />
          </div>
        </section>

        {/* ================= SHORTCUTS ================= */}

        <div className="mt-8 flex flex-col items-center gap-2 text-xs sm:text-sm">
          <Shortcut keys="tab" description="restart test" />

          <Shortcut keys="esc" description="command line" />

          <Shortcut
            keys="ctrl + shift + p"
            description="command palette"
          />
        </div>
      </main>
    </div>
  );
}

/* =========================================================
   METRIC
========================================================= */

type MetricProps = {
  label: string;
  value: string | number;
  subValue?: string;
};

function Metric({ label, value, subValue }: MetricProps) {
  return (
    <div
      className="
        rounded-xl
        border
        border-[#35383f]
        bg-[#1c1e23]
        px-5
        py-5
        transition-colors
        hover:border-[#464950]
      "
    >
      <div className="text-sm uppercase tracking-wide text-[#646669]">
        {label}
      </div>

      <div className="mt-2 break-all font-sans text-3xl font-medium text-[#e2b714]">
        {value}
      </div>

      {subValue && (
        <div className="mt-2 text-xs leading-5 text-[#646669]">
          {subValue}
        </div>
      )}
    </div>
  );
}

/* =========================================================
   INFO CARD
========================================================= */

type InfoCardProps = {
  icon: ReactNode;
  label: string;
  value: number;
};

function InfoCard({ icon, label, value }: InfoCardProps) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-[#35383f] bg-[#1c1e23] px-5 py-4">
      <div className="flex items-center gap-3">
        <div className="text-[#777a80]">{icon}</div>

        <span className="text-sm text-[#646669]">{label}</span>
      </div>

      <span className="font-sans text-xl text-[#e2b714]">{value}</span>
    </div>
  );
}

/* =========================================================
   ACTION BUTTON
========================================================= */

type ActionButtonProps = {
  icon: ReactNode;
  label: string;
  active?: boolean;
};

function ActionButton({
  icon,
  label,
  active = false,
}: ActionButtonProps) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      className={`
        group
        flex
        h-11
        min-w-11
        items-center
        justify-center
        rounded-lg
        border
        px-3
        transition-all

        ${
          active
            ? "border-[#4b4020] bg-[#29251b] text-[#e2b714]"
            : "border-transparent text-[#777a80] hover:border-[#35383f] hover:bg-[#1c1e23] hover:text-[#b5b6b8]"
        }
      `}
    >
      {icon}
    </button>
  );
}

/* =========================================================
   SHORTCUT
========================================================= */

type ShortcutProps = {
  keys: string;
  description: string;
};

function Shortcut({ keys, description }: ShortcutProps) {
  return (
    <div className="flex items-center gap-2">
      <kbd
        className="
          rounded-md
          border
          border-[#6d6f73]
          bg-[#85878b]
          px-2
          py-1
          text-[11px]
          font-sans
          font-semibold
          text-[#202329]
        "
      >
        {keys}
      </kbd>

      <span>— {description}</span>
    </div>
  );
}