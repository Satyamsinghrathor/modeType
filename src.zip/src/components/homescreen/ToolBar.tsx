import React, { useState } from "react";
import testTypes from "../../models/testType";
import testModes from "../../models/testMode";



type ToolBarProps = {
  onModeChange: (mode: string) => void;
  onTypeChange: (type: string) => void;
  onSelectorChange: (selector: number) => void;
};






export default function ToolBar(
  { onModeChange, onTypeChange, onSelectorChange }: ToolBarProps
) {

  const modes = testModes;
  const types = testTypes;

  const [type, setType] = useState("accuracy");
  const [mode, setMode] = useState("time");
  const [selector, setSelector] = useState(15);



  const selectors =
    mode === "time"
      ? [15, 30, 60, 120]
      : [10, 25, 50, 100];

  return (
    <div className="flex items-center gap-3 rounded-xl bg-zinc-800/60 px-4 py-3 text-zinc-500">

      {/* Type - accuracy, burst, test wpm */}
      <div className="flex items-center gap-1 border-r border-zinc-700 pr-3">
        {types.map((item) => (
          <button
            key={item}
            onClick={() => {setType(item)

              onTypeChange(item);

            }}
            className={`
              rounded-md px-3 py-2 text-sm transition
              ${
                type === item
                  ? "bg-zinc-700 text-yellow-400"
                  : "hover:bg-zinc-700/50 hover:text-zinc-300"
              }
            `}
          >
            {item}
          </button>
        ))}
      </div>

      {/* Mode - time, words */}
      <div className="flex items-center gap-1 border-r border-zinc-700 pr-3">
        {modes.map((item) => (
          <button
            key={item}
            onClick={() => {
              setMode(item);
              setSelector(item === "time" ? 15 : 10);

              onModeChange(item);
              onSelectorChange(item === "time" ? 15 : 10);
            }}
            className={`
              rounded-md px-3 py-2 text-sm transition
              ${
                mode === item
                  ? "bg-zinc-700 text-yellow-400"
                  : "hover:bg-zinc-700/50 hover:text-zinc-300"
              }
            `}
          >
            {item}
          </button>
        ))}
      </div>

      {/* Selector - duration / length */}
      <div className="flex items-center gap-1">
        {selectors.map((item) => (
          <button
            key={item}
            onClick={() => { setSelector(item); onSelectorChange(item); }}
            className={`
              rounded-md px-3 py-2 text-sm transition
              ${
                selector === item
                  ? "bg-zinc-700 text-yellow-400"
                  : "hover:bg-zinc-700/50 hover:text-zinc-300"
              }
            `}
          >
            {item}
          </button>
        ))}
      </div>

    </div>
  );
}