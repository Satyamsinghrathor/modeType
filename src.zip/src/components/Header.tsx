import React from 'react'
import {
  Bell,
  User,
  Keyboard,
  Crown,
  BarChart3,
  Info,
  Settings,
} from "lucide-react";

export default function Header() {
  return (
    <div>

            {/* ================= HEADER ================= */}
      <header className="flex items-center justify-between px-12 py-7">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg border-2 border-[#e2b714] text-[#e2b714]">
            <Keyboard size={26} />
          </div>

          <div className="leading-none">
            <div className="ml-1 text-[11px] text-[#646669]">
              by Satyam Singh
            </div>

            <div className="font-sans text-[30px] font-medium text-[#d1d0c5]">
              modeType
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mr-auto ml-8 flex items-center gap-7">
          <Keyboard size={19} />
          <Crown size={20} />
          <BarChart3 size={20} />
          <Info size={19} />
          <Settings size={20} />
        </nav>

        {/* User */}
        <div className="flex items-center gap-5">
          <Bell size={19} />

          <div className="flex items-center gap-2">
            <User size={18} />

            <span className="text-sm">
              satyam_0_7
            </span>

            <span className="rounded bg-[#646669] px-2 py-0.5 text-xs text-[#1f2126]">
              115
            </span>
          </div>
        </div>
      </header>

    </div>
  )
}
